CineCam Android - APK banane ke steps (v2: LUT, zebra, peaking, histogram, media, chat)

1) github.com par free account banao aur New repository banao (naam: CineCam).
2) Is zip ko unzip karo aur andar ki SAARI files/folders (.github folder samet) repo me upload karo
   (laptop par "Add file > Upload files" me folder drag-drop karo).
3) Repo ke "Actions" tab me "Build APK" run hone do (3-5 min).
4) Run complete hone par neeche "Artifacts" me CineCam-APK download karo, zip me app-debug.apk hai.
5) APK ko phone me install karo (Unknown sources allow karna padega).
