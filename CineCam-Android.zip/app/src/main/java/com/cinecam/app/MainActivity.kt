package com.cinecam.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.*
import android.hardware.camera2.CameraCharacteristics as CC
import android.hardware.camera2.CaptureRequest as CR
import android.media.*
import android.net.Uri
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.*
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.*
import android.widget.*
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.pow

class Lut(val name: String, val n: Int, val data: ByteArray)
class Item(val uri: Uri, val name: String, val vid: Boolean, val t: Long)

class HistView(c: Context) : View(c) {
    var h = Array(3) { IntArray(64) }
    private val p = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
    private val b = Paint().apply { color = 0x88000000.toInt() }
    override fun onDraw(cv: Canvas) {
        cv.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 12f, 12f, b)
        val mx = h.maxOf { it.max() }.coerceAtLeast(1)
        val cols = intArrayOf(0xFFEE3333.toInt(), 0xFF33CC33.toInt(), 0xFF3388FF.toInt())
        for (c in 0..2) {
            val path = Path()
            for (i in 0..63) {
                val x = i * width / 63f; val y = height - 4f - h[c][i].toFloat() / mx * (height - 8f)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            p.color = cols[c]; cv.drawPath(path, p)
        }
    }
}

class MeterView(c: Context) : View(c) {
    var lv = 0f
    private val p = Paint()
    override fun onDraw(cv: Canvas) {
        p.color = 0x88000000.toInt(); cv.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 12f, 12f, p)
        for (r in 0..1) {
            val y = height * (0.22f + 0.38f * r); val bh = height * 0.18f; val w = width - 24f; val e = w * lv.coerceIn(0f, 1f)
            p.color = 0xFF2FD24A.toInt(); cv.drawRect(12f, y, 12f + minOf(e, w * 0.7f), y + bh, p)
            if (e > w * 0.7f) { p.color = 0xFFE0C030.toInt(); cv.drawRect(12f + w * 0.7f, y, 12f + minOf(e, w * 0.9f), y + bh, p) }
            if (e > w * 0.9f) { p.color = 0xFFE03030.toInt(); cv.drawRect(12f + w * 0.9f, y, 12f + e, y + bh, p) }
        }
    }
}

class MainActivity : Activity() {
    private lateinit var gv: GLSurfaceView
    private lateinit var rd: Rend
    private lateinit var seek: SeekBar
    private lateinit var seekRow: LinearLayout
    private lateinit var autoB: Button
    private lateinit var recB: Button
    private lateinit var lutB: Button
    private lateinit var tc: TextView
    private lateinit var pill: TextView
    private lateinit var badge: TextView
    private lateinit var hv: HistView
    private lateinit var mv: MeterView
    private lateinit var camV: FrameLayout
    private lateinit var mediaV: LinearLayout
    private lateinit var chatV: LinearLayout
    private lateinit var setV: LinearLayout
    private lateinit var mGrid: GridLayout
    private lateinit var mHead: TextView
    private lateinit var lato: Typeface
    private lateinit var latoB: Typeface
    private val labels = HashMap<String, TextView>()
    private lateinit var cm: CameraManager
    private lateinit var ch: CC
    private var dev: CameraDevice? = null
    private var sess: CameraCaptureSession? = null
    private var opening = false
    private val bg = Handler(HandlerThread("cam").also { it.start() }.looper)
    private val mh = Handler(Looper.getMainLooper())
    private var pSize = Size(1920, 1080)
    private var vSize = Size(1920, 1080)
    private var ori = 90
    private var rawOk = false
    private var psurf: Surface? = null
    private var recSurf: Surface? = null
    private var jpegR: ImageReader? = null
    private var rawR: ImageReader? = null
    private var pendRes: TotalCaptureResult? = null
    private var pendImg: Image? = null
    private var rec: MediaRecorder? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var ar: AudioRecord? = null
    private var recording = false
    private var video = true
    private var rawOn = false
    private var uhd = false
    private var hevc = false
    private var histOn = true
    private var t0 = 0L
    private var proj = "My Project"
    private val luts = ArrayList<Lut>()
    private var curL = -1
    private val auto = hashMapOf("iso" to true, "shutter" to true, "wb" to true, "focus" to true)
    private var isoV = 400; private var shD = 60; private var wbI = 2; private var foc = 0f; private var fps = 24
    private var sel = ""
    private var isoR: Range<Int> = Range(100, 3200)
    private var expR: Range<Long> = Range(100000L, 1000000000L)
    private var minFoc = 0f
    private var fpsRanges: Array<Range<Int>> = arrayOf()
    private val shL = intArrayOf(30, 48, 50, 60, 100, 125, 250, 500, 1000, 2000)
    private val wbK = intArrayOf(2800, 4000, 5600, 6500, 7500)
    private val wbM = intArrayOf(CR.CONTROL_AWB_MODE_INCANDESCENT, CR.CONTROL_AWB_MODE_FLUORESCENT, CR.CONTROL_AWB_MODE_DAYLIGHT, CR.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT, CR.CONTROL_AWB_MODE_SHADE)
    private val fpsL = intArrayOf(24, 25, 30, 60)

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
    private fun perms() = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun isoMax() = minOf(isoR.upper, 6400)
    private fun <T : TextView> T.f(bold: Boolean = false): T { typeface = if (bold) latoB else lato; return this }
    private fun btn(t: String, sz: Float = 13f, f: () -> Unit) = Button(this).f().apply {
        text = t; setTextColor(Color.WHITE); setBackgroundColor(Color.TRANSPARENT); textSize = sz; isAllCaps = false; setOnClickListener { f() }
    }
    private fun head(t: String) = TextView(this).f().apply { text = t; textSize = 20f; setTextColor(Color.WHITE); setBackgroundColor(0xFF3A3D44.toInt()); setPadding(dp(14), dp(34), dp(14), dp(12)) }

    // ---------- GL renderer: camera -> LUT / zebra / peaking -> screen, plus histogram ----------
    inner class Rend : GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {
        @Volatile var st: SurfaceTexture? = null
        @Volatile var lutOn = false
        @Volatile var zeb = false
        @Volatile var pk = false
        @Volatile var pending: Lut? = null
        private var oes = 0; private var lt = 0; private var ft = 0; private var fbo = 0; private var prog = 0
        private val U = IntArray(7)
        private var curN = 2f; private var w = 1; private var h = 1; private var fc = 0
        private val m = FloatArray(16)
        private val rb = ByteBuffer.allocateDirect(64 * 114 * 4)
        private val quad = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0) }

        private fun tp(t: Int, f: Int) {
            GLES20.glTexParameteri(t, GLES20.GL_TEXTURE_MIN_FILTER, f); GLES20.glTexParameteri(t, GLES20.GL_TEXTURE_MAG_FILTER, f)
            GLES20.glTexParameteri(t, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE); GLES20.glTexParameteri(t, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }
        private fun sh(type: Int, src: String): Int { val s = GLES20.glCreateShader(type); GLES20.glShaderSource(s, src); GLES20.glCompileShader(s); return s }

        override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) {
            val t = IntArray(3); GLES20.glGenTextures(3, t, 0); oes = t[0]; lt = t[1]; ft = t[2]
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oes); tp(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_LINEAR)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, lt); tp(GLES20.GL_TEXTURE_2D, GLES20.GL_NEAREST)
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, 1, 1, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, ByteBuffer.allocateDirect(4))
            GLES20.glActiveTexture(GLES20.GL_TEXTURE2); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ft); tp(GLES20.GL_TEXTURE_2D, GLES20.GL_LINEAR)
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, 64, 114, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
            val fb = IntArray(1); GLES20.glGenFramebuffers(1, fb, 0); fbo = fb[0]
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
            GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, ft, 0)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            val vs = "attribute vec2 p;uniform mat4 uM;uniform float uOri;varying vec2 v;" +
                    "void main(){vec2 t=uOri>180.?vec2((1.+p.y)/2.,(1.-p.x)/2.):vec2((1.-p.y)/2.,(p.x+1.)/2.);v=(uM*vec4(t,0.,1.)).xy;gl_Position=vec4(p,0.,1.);}"
            val fs = """#extension GL_OES_EGL_image_external : require
precision highp float;varying vec2 v;uniform samplerExternalOES uV;uniform sampler2D uL;uniform float uN,uLut,uZ,uP;uniform vec2 uPx;
float Y(vec3 c){return dot(c,vec3(.299,.587,.114));}
vec3 lut(vec3 c){c=clamp(c,0.,1.);float n=uN,b=c.b*(n-1.),b0=floor(b),b1=min(b0+1.,n-1.),f=b-b0;
vec2 a=vec2((b0*n+c.r*(n-1.)+.5)/(n*n),(c.g*(n-1.)+.5)/n),d=vec2((b1*n+c.r*(n-1.)+.5)/(n*n),a.y);return mix(texture2D(uL,a).rgb,texture2D(uL,d).rgb,f);}
void main(){vec3 c=texture2D(uV,v).rgb;float l=Y(c);float e=abs(l-Y(texture2D(uV,v+vec2(uPx.x,0.)).rgb))+abs(l-Y(texture2D(uV,v+vec2(0.,uPx.y)).rgb));
if(uLut>.5)c=lut(c);if(uP>.5&&e>.1)c=vec3(1.,.1,.1);
if(uZ>.5&&l>.95&&fract((gl_FragCoord.x+gl_FragCoord.y)/14.)>.5)c=vec3(.55)+c*.2;gl_FragColor=vec4(c,1.);}"""
            prog = GLES20.glCreateProgram(); GLES20.glAttachShader(prog, sh(GLES20.GL_VERTEX_SHADER, vs)); GLES20.glAttachShader(prog, sh(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(prog); GLES20.glUseProgram(prog)
            for ((i, n) in listOf("uM", "uN", "uLut", "uZ", "uP", "uPx", "uOri").withIndex()) U[i] = GLES20.glGetUniformLocation(prog, n)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uV"), 0); GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uL"), 1)
            val pl = GLES20.glGetAttribLocation(prog, "p"); GLES20.glEnableVertexAttribArray(pl); GLES20.glVertexAttribPointer(pl, 2, GLES20.GL_FLOAT, false, 0, quad)
            val s = SurfaceTexture(oes); s.setOnFrameAvailableListener(this); st = s
            runOnUiThread { if (dev != null) startPreview() }
        }
        override fun onSurfaceChanged(g: GL10?, w: Int, h: Int) { this.w = w; this.h = h; GLES20.glViewport(0, 0, w, h) }
        override fun onFrameAvailable(s: SurfaceTexture?) { gv.requestRender() }

        private fun draw(z: Float, p: Float, l: Float) {
            GLES20.glUniform1f(U[2], l); GLES20.glUniform1f(U[3], z); GLES20.glUniform1f(U[4], p)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        }

        override fun onDrawFrame(g: GL10?) {
            val s = st ?: return
            try { s.updateTexImage() } catch (e: Exception) { return }
            s.getTransformMatrix(m)
            val l = pending
            if (l != null) {
                pending = null
                val bb = ByteBuffer.allocateDirect(l.data.size); bb.put(l.data); bb.position(0)
                GLES20.glActiveTexture(GLES20.GL_TEXTURE1); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, lt); GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1)
                GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, l.n * l.n, l.n, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, bb); curN = l.n.toFloat()
            }
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glUniformMatrix4fv(U[0], 1, false, m, 0); GLES20.glUniform1f(U[1], curN); GLES20.glUniform1f(U[6], ori.toFloat())
            GLES20.glUniform2f(U[5], 1f / pSize.width, 1f / pSize.height)
            val lo = if (lutOn) 1f else 0f
            draw(if (zeb) 1f else 0f, if (pk) 1f else 0f, lo)
            if (histOn && ++fc % 5 == 0) {
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo); GLES20.glViewport(0, 0, 64, 114)
                draw(0f, 0f, lo)
                rb.position(0); GLES20.glReadPixels(0, 0, 64, 114, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, rb)
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0); GLES20.glViewport(0, 0, w, h)
                val bins = Array(3) { IntArray(64) }
                for (i in 0 until 64 * 114) for (c in 0..2) bins[c][(rb.get(i * 4 + c).toInt() and 255) shr 2]++
                runOnUiThread { hv.h = bins; hv.invalidate() }
            }
        }
    }

    // ---------- UI ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        lato = resources.getFont(R.font.lato_regular); latoB = resources.getFont(R.font.lato_bold)
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        File(filesDir, "luts").listFiles()?.forEach { try { luts.add(parseCube(it.nameWithoutExtension, it.readText())) } catch (e: Exception) {} }
        val w = resources.displayMetrics.widthPixels
        camV = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        gv = GLSurfaceView(this).apply { setEGLContextClientVersion(2); rd = Rend(); setRenderer(rd); renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY }
        camV.addView(gv, FrameLayout.LayoutParams(w, w * 16 / 9, Gravity.TOP))
        val grid = object : View(this) {
            val p = Paint().apply { color = Color.WHITE; strokeWidth = 2f }
            override fun onDraw(c: Canvas) { for (i in 1..2) { c.drawLine(width * i / 3f, 0f, width * i / 3f, height.toFloat(), p); c.drawLine(0f, height * i / 3f, width.toFloat(), height * i / 3f, p) } }
        }.apply { visibility = View.GONE }
        camV.addView(grid, FrameLayout.LayoutParams(w, w * 16 / 9, Gravity.TOP))
        val hudL = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(24), dp(8), 0) }
        pill = TextView(this).f().apply { text = proj; textSize = 12f; setTextColor(Color.WHITE); setBackgroundColor(0xFF2F8CF5.toInt()); setPadding(dp(10), 0, dp(10), 0) }
        hudL.addView(pill, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        val tr = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        badge = TextView(this).f(true).apply { text = "HD"; textSize = 13f; setTextColor(Color.BLACK); setBackgroundColor(Color.WHITE); setPadding(dp(5), 0, dp(5), 0) }
        tc = TextView(this).f().apply { text = "00:00:00:00"; textSize = 32f; setTextColor(Color.WHITE); setShadowLayer(4f, 0f, 1f, Color.BLACK); setPadding(dp(8), 0, 0, 0) }
        tr.addView(badge); tr.addView(tc); hudL.addView(tr)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (k in listOf("fps", "shutter", "iso", "wb", "focus")) {
            val t = TextView(this).f().apply { textSize = 15f; gravity = Gravity.CENTER; setShadowLayer(4f, 0f, 1f, Color.BLACK); setOnClickListener { select(k) } }
            labels[k] = t; row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        hudL.addView(row); camV.addView(hudL, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        hv = HistView(this); camV.addView(hv, FrameLayout.LayoutParams(dp(120), dp(50), Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(8), 0, 0, dp(190)) })
        mv = MeterView(this); camV.addView(mv, FrameLayout.LayoutParams(dp(150), dp(40), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(8), dp(190)) })
        // controls panel
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0B1220.toInt()) }
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { if (u) onSeek(p) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        autoB = btn("AUTO") { if (sel != "fps") { auto[sel] = !auto[sel]!!; hud(); applyRepeat() } }
        seekRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
        seekRow.addView(seek, LinearLayout.LayoutParams(0, -2, 1f)); seekRow.addView(autoB); panel.addView(seekRow)
        val tools = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val tl = LinearLayout.LayoutParams(0, -2, 1f)
        lutB = btn("LUT OFF", 11f) {
            if (luts.isEmpty()) pickLut() else { curL++; if (curL >= luts.size) curL = -1; applyLut() }
        }
        lutB.setOnLongClickListener {
            if (curL >= 0) { File(filesDir, "luts/${luts[curL].name}.cube").delete(); luts.removeAt(curL); curL = -1; applyLut(); toast("LUT hata diya") }; true
        }
        tools.addView(lutB, tl); tools.addView(btn("+LUT", 11f) { pickLut() }, tl)
        val hb = btn("HIST", 11f) {}; hb.setOnClickListener { histOn = !histOn; hv.visibility = if (histOn) View.VISIBLE else View.GONE; mv.visibility = hv.visibility; hb.setTextColor(if (histOn) Color.WHITE else Color.GRAY) }
        val zb = btn("ZEBRA", 11f) {}; zb.setTextColor(Color.GRAY); zb.setOnClickListener { rd.zeb = !rd.zeb; zb.setTextColor(if (rd.zeb) 0xFFFFD23F.toInt() else Color.GRAY) }
        val pb = btn("PEAK", 11f) {}; pb.setTextColor(Color.GRAY); pb.setOnClickListener { rd.pk = !rd.pk; pb.setTextColor(if (rd.pk) 0xFFFFD23F.toInt() else Color.GRAY) }
        val gb = btn("GRID", 11f) {}; gb.setTextColor(Color.GRAY); gb.setOnClickListener { val on = grid.visibility == View.GONE; grid.visibility = if (on) View.VISIBLE else View.GONE; gb.setTextColor(if (on) 0xFFFFD23F.toInt() else Color.GRAY) }
        for (x in listOf(hb, zb, pb, gb)) tools.addView(x, tl)
        panel.addView(tools)
        val br = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(10)) }
        val modeB = btn("VIDEO") {}
        modeB.setOnClickListener { if (recording) return@setOnClickListener; video = !video; modeB.text = if (video) "VIDEO" else "PHOTO"; startPreview() }
        val rawB = btn("RAW OFF") {}
        rawB.setOnClickListener { if (!rawOk) toast("Is phone me RAW support nahi hai") else { rawOn = !rawOn; rawB.text = if (rawOn) "RAW ON" else "RAW OFF"; if (!video) startPreview() } }
        recB = Button(this).f().apply {
            textSize = 22f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFE5251F.toInt()); setStroke(dp(3), Color.WHITE) }
            setOnClickListener { if (video) { if (recording) stopRec() else startRec() } else shoot() }
        }
        val resB = btn("HD") {}
        resB.setOnClickListener { if (recording) return@setOnClickListener; uhd = !uhd; resB.text = if (uhd) "4K" else "HD"; badge.text = resB.text }
        val fpsB = btn("FPS") { select("fps") }
        br.addView(modeB, tl); br.addView(rawB, tl); br.addView(recB, LinearLayout.LayoutParams(dp(64), dp(64))); br.addView(resB, tl); br.addView(fpsB, tl)
        panel.addView(br)
        camV.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        // media tab
        mediaV = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; setBackgroundColor(0xFF0E0F12.toInt()) }
        mHead = head(proj); mediaV.addView(mHead)
        mGrid = GridLayout(this).apply { columnCount = 3; setPadding(dp(6), dp(6), dp(6), dp(6)) }
        mediaV.addView(ScrollView(this).apply { addView(mGrid) }, LinearLayout.LayoutParams(-1, 0, 1f))
        // chat tab
        chatV = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; setBackgroundColor(0xFF0E0F12.toInt()) }
        val msgs = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        fun bubble(t: String, me: Boolean) { msgs.addView(TextView(this).f().apply { text = t; textSize = 15f; setTextColor(Color.WHITE); setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(if (me) 0xFF2F8CF5.toInt() else 0xFF1F2127.toInt()) }, LinearLayout.LayoutParams(-2, -2).apply { gravity = if (me) Gravity.END else Gravity.START; bottomMargin = dp(8) }) }
        bubble("Crew ke notes yahan likho (ye sirf is phone me save hote hain).", false)
        chatV.addView(head("Chat")); chatV.addView(ScrollView(this).apply { addView(msgs) }, LinearLayout.LayoutParams(-1, 0, 1f))
        val inp = EditText(this).f().apply { hint = "Message"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        val cr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        cr.addView(inp, LinearLayout.LayoutParams(0, -2, 1f)); cr.addView(btn("Send") { val t = inp.text.toString().trim(); if (t.isNotEmpty()) { bubble(t, true); inp.setText("") } })
        chatV.addView(cr)
        // settings tab
        setV = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; setBackgroundColor(0xFF0E0F12.toInt()) }
        setV.addView(head("Settings"))
        val pn = EditText(this).f().apply { setText(proj); setTextColor(Color.WHITE); setPadding(dp(16), dp(12), dp(16), dp(12)) }
        pn.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { proj = s.toString().ifEmpty { "My Project" }; pill.text = proj; mHead.text = proj }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        setV.addView(TextView(this).f().apply { text = "Project name"; setTextColor(Color.GRAY); setPadding(dp(16), dp(12), dp(16), 0) }); setV.addView(pn)
        val cb = btn("Codec: H.264 (tap to switch to H.265)") {}
        cb.setOnClickListener { hevc = !hevc; cb.text = if (hevc) "Codec: H.265 (tap to switch to H.264)" else "Codec: H.264 (tap to switch to H.265)" }
        setV.addView(cb)
        val content = FrameLayout(this); content.addView(camV); content.addView(mediaV); content.addView(chatV); content.addView(setV)
        val nav = LinearLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val tabs = listOf<View>(camV, mediaV, chatV, setV)
        listOf("Camera", "Media", "Chat", "Settings").forEachIndexed { i, n ->
            nav.addView(btn(n, 13f) { tabs.forEachIndexed { j, v -> v.visibility = if (i == j) View.VISIBLE else View.GONE }; if (i == 1) loadMedia() }.apply { setTextColor(0xFF7AA8FF.toInt()) }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK); addView(content, LinearLayout.LayoutParams(-1, 0, 1f)); addView(nav) })
        hud(); applyLut()
        if (!perms()) requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
    }

    private fun hud() = runOnUiThread {
        labels["fps"]?.text = "FPS\n$fps"
        labels["shutter"]?.text = "SHUTTER\n" + if (auto["shutter"]!!) "AUTO" else "1/$shD"
        labels["iso"]?.text = "ISO\n" + if (auto["iso"]!!) "AUTO" else "$isoV"
        labels["wb"]?.text = "WB\n" + if (auto["wb"]!!) "AUTO" else "${wbK[wbI]}K"
        labels["focus"]?.text = "FOCUS\n" + if (auto["focus"]!!) "AF" else "MF"
        labels.forEach { (k, v) -> v.setTextColor(if (k == sel) 0xFFFFD23F.toInt() else Color.WHITE) }
    }

    private fun select(k: String) {
        sel = k; seekRow.visibility = View.VISIBLE
        when (k) {
            "iso" -> { seek.max = 100; seek.progress = (Math.log(isoV.toDouble() / isoR.lower) / Math.log(isoMax() / isoR.lower.toDouble()) * 100).toInt().coerceIn(0, 100) }
            "shutter" -> { seek.max = shL.size - 1; seek.progress = shL.indexOf(shD).coerceAtLeast(0) }
            "wb" -> { seek.max = wbK.size - 1; seek.progress = wbI }
            "focus" -> { seek.max = 100; seek.progress = if (minFoc > 0) (foc / minFoc * 100).toInt() else 0 }
            "fps" -> { seek.max = fpsL.size - 1; seek.progress = fpsL.indexOf(fps).coerceAtLeast(0) }
        }
        hud()
    }

    private fun onSeek(p: Int) {
        when (sel) {
            "iso" -> isoV = (isoR.lower * (isoMax() / isoR.lower.toDouble()).pow(p / 100.0)).toInt().coerceIn(isoR.lower, isoR.upper)
            "shutter" -> shD = shL[p]
            "wb" -> wbI = p
            "focus" -> foc = minFoc * p / 100f
            "fps" -> fps = fpsL[p]
        }
        if (sel != "fps") auto[sel] = false
        hud(); applyRepeat()
    }

    // ---------- LUT ----------
    private fun parseCube(name: String, txt: String): Lut {
        var n = 0; val d = ArrayList<Float>()
        for (l in txt.lineSequence()) {
            val t = l.trim()
            if (t.isEmpty() || t[0] == '#') continue
            if (t.startsWith("LUT_3D_SIZE")) n = t.split(Regex("\\s+"))[1].toInt()
            else if (t[0].isDigit() || t[0] == '-' || t[0] == '.') { val p = t.split(Regex("\\s+")); if (p.size >= 3) { d.add(p[0].toFloat()); d.add(p[1].toFloat()); d.add(p[2].toFloat()) } }
        }
        if (n < 2 || n * n > 4096 || d.size < n * n * n * 3) throw IllegalArgumentException("bad lut")
        val u = ByteArray(n * n * n * 4)
        for (i in 0 until n * n * n) {
            for (c in 0..2) u[i * 4 + c] = (d[i * 3 + c].coerceIn(0f, 1f) * 255f + 0.5f).toInt().toByte()
            u[i * 4 + 3] = 255.toByte()
        }
        return Lut(name, n, u)
    }

    private fun pickLut() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 7)
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        val u = d?.data
        if (rq == 7 && rs == RESULT_OK && u != null) try {
            val txt = contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }
            val nm = (u.lastPathSegment ?: "lut").substringAfterLast('/').substringAfterLast(':').substringBeforeLast('.').take(24)
            luts.add(parseCube(nm, txt)); File(filesDir, "luts").mkdirs(); File(filesDir, "luts/$nm.cube").writeText(txt)
            curL = luts.size - 1; applyLut()
        } catch (e: Exception) { toast("Ye LUT support nahi hai (3D .cube, size 64 tak)") }
    }

    private fun applyLut() {
        rd.lutOn = curL >= 0
        if (curL >= 0) rd.pending = luts[curL]
        lutB.text = if (curL >= 0) "LUT:" + luts[curL].name.take(8) else "LUT OFF"
        lutB.setTextColor(if (curL >= 0) 0xFFFFD23F.toInt() else Color.WHITE)
    }

    // ---------- Camera2 ----------
    private fun manual(b: CR.Builder) {
        val ae = auto["iso"]!! && auto["shutter"]!!
        if (ae) b.set(CR.CONTROL_AE_MODE, CR.CONTROL_AE_MODE_ON) else {
            b.set(CR.CONTROL_AE_MODE, CR.CONTROL_AE_MODE_OFF)
            b.set(CR.SENSOR_SENSITIVITY, isoV.coerceIn(isoR.lower, isoR.upper))
            b.set(CR.SENSOR_EXPOSURE_TIME, (1_000_000_000L / shD).coerceIn(expR.lower, expR.upper))
        }
        b.set(CR.CONTROL_AWB_MODE, if (auto["wb"]!!) CR.CONTROL_AWB_MODE_AUTO else wbM[wbI])
        if (auto["focus"]!!) b.set(CR.CONTROL_AF_MODE, if (video) CR.CONTROL_AF_MODE_CONTINUOUS_VIDEO else CR.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        else { b.set(CR.CONTROL_AF_MODE, CR.CONTROL_AF_MODE_OFF); b.set(CR.LENS_FOCUS_DISTANCE, foc) }
        val r = fpsRanges.firstOrNull { it.lower == fps && it.upper == fps }
        if (r != null && video) b.set(CR.CONTROL_AE_TARGET_FPS_RANGE, r)
    }

    @SuppressLint("MissingPermission")
    private fun openCam() {
        if (dev != null || opening) return
        opening = true
        val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CC.LENS_FACING) == CC.LENS_FACING_BACK }
        ch = cm.getCameraCharacteristics(id)
        ori = ch.get(CC.SENSOR_ORIENTATION) ?: 90
        isoR = ch.get(CC.SENSOR_INFO_SENSITIVITY_RANGE) ?: isoR
        expR = ch.get(CC.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: expR
        minFoc = ch.get(CC.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        fpsRanges = ch.get(CC.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: arrayOf()
        rawOk = ch.get(CC.REQUEST_AVAILABLE_CAPABILITIES)?.contains(CC.REQUEST_AVAILABLE_CAPABILITIES_RAW) == true
        val map = ch.get(CC.SCALER_STREAM_CONFIGURATION_MAP)!!
        pSize = map.getOutputSizes(SurfaceTexture::class.java).filter { it.height <= 1080 && it.width * 9 == it.height * 16 }.maxByOrNull { it.width * it.height } ?: Size(1280, 720)
        cm.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(c: CameraDevice) { dev = c; opening = false; startPreview() }
            override fun onDisconnected(c: CameraDevice) { c.close(); dev = null; opening = false }
            override fun onError(c: CameraDevice, e: Int) { c.close(); dev = null; opening = false }
        }, bg)
    }

    private fun startPreview() {
        val d = dev ?: return
        val st = rd.st ?: return
        try { sess?.close() } catch (e: Exception) {}
        st.setDefaultBufferSize(pSize.width, pSize.height)
        val ps = Surface(st); psurf = ps
        val outs = arrayListOf(ps)
        jpegR?.close(); rawR?.close(); jpegR = null; rawR = null
        if (!video) {
            val map = ch.get(CC.SCALER_STREAM_CONFIGURATION_MAP)!!
            if (rawOn && rawOk) {
                val rs = map.getOutputSizes(ImageFormat.RAW_SENSOR).maxByOrNull { it.width * it.height }!!
                rawR = ImageReader.newInstance(rs.width, rs.height, ImageFormat.RAW_SENSOR, 2).also { r ->
                    r.setOnImageAvailableListener({ x -> pendImg?.close(); pendImg = x.acquireNextImage(); trySaveRaw() }, bg); outs.add(r.surface)
                }
            } else {
                val js = map.getOutputSizes(ImageFormat.JPEG).filter { it.width * it.height <= 12_600_000 }.maxByOrNull { it.width * it.height } ?: map.getOutputSizes(ImageFormat.JPEG).first()
                jpegR = ImageReader.newInstance(js.width, js.height, ImageFormat.JPEG, 2).also { r ->
                    r.setOnImageAvailableListener({ x ->
                        val im = x.acquireNextImage()
                        if (im != null) try {
                            val buf = im.planes[0].buffer; val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                            saveImg("IMG_${System.currentTimeMillis()}.jpg", "image/jpeg") { it.write(bytes) }
                        } finally { im.close() }
                    }, bg); outs.add(r.surface)
                }
            }
        }
        d.createCaptureSession(outs, object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) { sess = s; applyRepeat() }
            override fun onConfigureFailed(s: CameraCaptureSession) { toast("Camera session start nahi hua") }
        }, bg)
    }

    private fun applyRepeat() {
        val d = dev ?: return; val s = sess ?: return; val ps = psurf ?: return
        try {
            val b = d.createCaptureRequest(if (recording) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW)
            b.addTarget(ps); if (recording) recSurf?.let { b.addTarget(it) }
            manual(b); s.setRepeatingRequest(b.build(), null, bg)
        } catch (e: Exception) {}
    }

    private fun shoot() {
        val d = dev ?: return; val s = sess ?: return
        val raw = rawR; val jp = jpegR
        val target = (if (rawOn && raw != null) raw.surface else jp?.surface) ?: return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(target); manual(b); b.set(CR.JPEG_ORIENTATION, ori)
            s.capture(b.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(se: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) { if (rawOn && raw != null) { pendRes = res; trySaveRaw() } }
            }, bg)
        } catch (e: Exception) { toast("Photo error: ${e.message}") }
    }

    @Synchronized private fun trySaveRaw() {
        val im = pendImg; val rs = pendRes
        if (im == null || rs == null) return
        pendImg = null; pendRes = null
        try {
            val dng = DngCreator(ch, rs); dng.setOrientation(6)
            saveImg("RAW_${System.currentTimeMillis()}.dng", "image/x-adobe-dng") { dng.writeImage(it, im) }; dng.close()
        } catch (e: Exception) { toast("RAW error: ${e.message}") } finally { im.close() }
    }

    private fun saveImg(name: String, mime: String, write: (java.io.OutputStream) -> Unit) {
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, mime); put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CineCam")
        }
        val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return
        contentResolver.openOutputStream(u)?.use(write)
        toast("Saved $name")
    }

    private fun startRec() {
        val d = dev ?: return
        val st = rd.st ?: return
        stopMeter()
        val map = ch.get(CC.SCALER_STREAM_CONFIGURATION_MAP)!!
        vSize = map.getOutputSizes(MediaRecorder::class.java).filter { it.height <= (if (uhd) 2160 else 1080) && it.width * 9 == it.height * 16 }.maxByOrNull { it.width * it.height } ?: pSize
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VID_${System.currentTimeMillis()}.mp4"); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4"); put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CineCam")
        }
        val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return
        recPfd = contentResolver.openFileDescriptor(u, "w")
        val r = MediaRecorder()
        try {
            r.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC); setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); setOutputFile(recPfd!!.fileDescriptor)
                setVideoEncodingBitRate(if (uhd) 60_000_000 else 30_000_000); setVideoFrameRate(fps)
                setVideoSize(vSize.width, vSize.height); setVideoEncoder(if (hevc) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setOrientationHint(ori); prepare()
            }
        } catch (e: Exception) { toast("Record setup fail: ${e.message}"); r.release(); startMeter(); return }
        rec = r; recSurf = r.surface
        try { sess?.close() } catch (e: Exception) {}
        st.setDefaultBufferSize(pSize.width, pSize.height)
        val ps = Surface(st); psurf = ps
        d.createCaptureSession(listOf(ps, r.surface), object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                sess = s; recording = true; applyRepeat(); r.start(); t0 = SystemClock.elapsedRealtime()
                runOnUiThread { recB.text = "■"; tc.post(tick) }
            }
            override fun onConfigureFailed(s: CameraCaptureSession) { toast("Record start nahi hua") }
        }, bg)
    }

    private fun stopRec() {
        recording = false
        try { sess?.stopRepeating(); rec?.stop() } catch (e: Exception) {}
        rec?.release(); rec = null; recSurf = null
        try { recPfd?.close() } catch (e: Exception) {}
        toast("Video saved (Movies/CineCam)")
        runOnUiThread { recB.text = ""; tc.post(tick) }
        startPreview(); startMeter()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (recording) {
                val ms = SystemClock.elapsedRealtime() - t0; val s = ms / 1000
                tc.text = String.format("%02d:%02d:%02d:%02d", s / 3600, s / 60 % 60, s % 60, (ms % 1000) * fps / 1000)
                tc.setTextColor(Color.RED); tc.postDelayed(this, 40)
            } else { tc.text = "00:00:00:00"; tc.setTextColor(Color.WHITE) }
        }
    }

    // ---------- audio meter ----------
    private fun startMeter() {
        if (ar != null || !perms()) return
        try {
            val bs = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            ar = AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bs).also { it.startRecording() }
        } catch (e: Exception) { ar = null }
    }
    private fun stopMeter() { try { ar?.stop(); ar?.release() } catch (e: Exception) {}; ar = null }
    private val meterTick = object : Runnable {
        override fun run() {
            var peak = 0
            if (recording) peak = try { rec?.maxAmplitude ?: 0 } catch (e: Exception) { 0 }
            else ar?.let { a -> val buf = ShortArray(1024); val n = a.read(buf, 0, 1024, AudioRecord.READ_NON_BLOCKING); for (i in 0 until n) peak = maxOf(peak, abs(buf[i].toInt())) }
            val db = if (peak > 0) 20 * log10(peak / 32768.0) else -80.0
            mv.lv = ((db + 60) / 60).toFloat().coerceIn(0f, 1f); mv.invalidate()
            mh.postDelayed(this, 80)
        }
    }

    // ---------- media tab ----------
    private fun loadMedia() {
        mGrid.removeAllViews()
        Thread {
            val items = ArrayList<Item>()
            fun q(base: Uri, rel: String, vid: Boolean) {
                contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DATE_ADDED),
                    "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("$rel%"), null)?.use { c ->
                    while (c.moveToNext()) items.add(Item(ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1), vid, c.getLong(2)))
                }
            }
            q(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "Pictures/CineCam", false)
            q(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "Movies/CineCam", true)
            items.sortByDescending { it.t }
            val cw = (resources.displayMetrics.widthPixels - dp(12)) / 3
            for (it in items.take(60)) {
                val bmp = try { contentResolver.loadThumbnail(it.uri, Size(320, 180), null) } catch (e: Exception) { null }
                runOnUiThread {
                    val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(3), dp(3), dp(3), dp(3)) }
                    cell.addView(ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF222222.toInt()); if (bmp != null) setImageBitmap(bmp) }, LinearLayout.LayoutParams(cw - dp(6), (cw - dp(6)) * 9 / 16))
                    cell.addView(TextView(this).f().apply { text = (if (it.vid) "▶ " else "") + it.name.substringBeforeLast('.'); textSize = 11f; setTextColor(Color.WHITE); maxLines = 1 })
                    cell.setOnClickListener { _ -> startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it.uri, contentResolver.getType(it.uri)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                    cell.setOnLongClickListener { _ ->
                        AlertDialog.Builder(this).setMessage("${it.name} delete karein?").setPositiveButton("Delete") { _, _ -> try { contentResolver.delete(it.uri, null, null) } catch (e: Exception) {}; loadMedia() }.setNegativeButton("Cancel", null).show(); true
                    }
                    mGrid.addView(cell)
                }
            }
            if (items.isEmpty()) runOnUiThread { mGrid.addView(TextView(this).f().apply { text = "Abhi koi clip nahi hai."; setTextColor(Color.GRAY); setPadding(dp(16), dp(20), 0, 0) }) }
        }.start()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { if (perms()) { openCam(); startMeter() } }
    override fun onResume() { super.onResume(); gv.onResume(); if (perms()) { openCam(); startMeter() }; mh.post(meterTick) }
    override fun onPause() {
        if (recording) stopRec()
        mh.removeCallbacks(meterTick); stopMeter()
        try { sess?.close() } catch (e: Exception) {}
        dev?.close(); dev = null; opening = false; rd.st = null
        gv.onPause(); super.onPause()
    }
}
